# MITRE ATT&CK Mapping Tool (V1)

Maps security logs, command lines and threat descriptions to MITRE ATT&CK techniques/tactics with a heuristic confidence score.

**Pipeline:** text -> normalizer -> rule matching (`rules/rules.json`) + technique-name similarity -> ranked results.
MITRE STIX 2.1 data is synced into SQLite (auto every 24h, or `POST /api/v1/admin/sync`). A small offline seed is loaded on first start.

## Run
```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
uvicorn backend.app.main:app --reload      # http://localhost:8000  (docs: /docs)
python scripts/sync_mitre.py               # optional manual full sync
pytest -q
docker compose up --build                  # alternative
```

## API
| Method | Path | Purpose |
|---|---|---|
| POST | `/api/v1/map` | `{"text": "..."}` -> matches |
| POST | `/api/v1/map/file` | upload .txt/.log/.csv/.json (1 MB max) |
| GET | `/api/v1/techniques?q=&tactic=` , `/techniques/{id}` | browse MITRE data |
| GET | `/api/v1/history` , `/export/{id}?format=json\|csv` | past analyses |
| POST | `/api/v1/admin/sync` | resync MITRE (header `X-Admin-Token` if `ADMIN_TOKEN` set) |
| GET | `/api/v1/health` | status |

## Config (env)
`DATABASE_URL`, `AUTO_SYNC`, `SYNC_INTERVAL_HOURS`, `ADMIN_TOKEN`, `MAX_UPLOAD_BYTES`, `MAX_TEXT_CHARS`, `STIX_URL`.

## Security notes
Input is only ever treated as text (never executed); ORM-parameterized queries; upload extension/size limits; CSV export neutralizes formula injection; UI renders with `textContent` (XSS-safe); set `ADMIN_TOKEN` in production.

## Add a rule
Append to `rules/rules.json`: `{"attack_id","name","tactics":[...],"indicators":[...],"weight":0.7}` and restart.

## Roadmap
V2: sentence-transformer embeddings + FAISS/Chroma, LLM explanations. V3: Wazuh/Splunk ingestion, Sigma, ATT&CK Navigator export, auth/RBAC.
